## Run the following three commands before installing new version

tmp <- installed.packages()
installedpkgs <- as.vector(tmp[is.na(tmp[,"Priority"]), 1])
save(installedpkgs, file="installed_old.rda")


## Install the new version of R and RStudio.

## Once you’ve got the new version up and running, 
## reload the saved packages by running this command:

load("installed_old.rda")

# Now reinstall them from CRAN by running these five commands:

tmp <- installed.packages()
installedpkgs.new <- as.vector(tmp[is.na(tmp[,"Priority"]), 1])
missing <- setdiff(installedpkgs, installedpkgs.new)
install.packages(missing)
update.packages()
