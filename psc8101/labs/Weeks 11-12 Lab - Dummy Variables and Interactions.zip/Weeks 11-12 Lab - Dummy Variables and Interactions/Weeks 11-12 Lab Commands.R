library(haven)
library(tidyverse)
library(marginaleffects) 
library(jtools)

states <- read_dta("states.dta")
nes <- read_dta("nes.dta")

## Dummy variables

# Frequency distribution, south
states |> group_by(south) |> summarize(n=n()) |> mutate(pct=100*n/sum(n))

# Turnout, South v. non-South
states |> group_by(south) |> summarize(avg=mean(vep16_turnout))

# Difference of means test
t.test(vep16_turnout ~ south, data = states, var.equal = TRUE)

# Simple (bivariate) regression
summary(lm(vep16_turnout ~ south, data=states), digits=4)

# Multiple regression
summary(lm(vep16_turnout ~ south + ba_or_more_2015 + hispanicpct_2016, data=states),
     digits=4)

# Nominal independent variables - 3 category race variable
nes |> group_by(Race3) |> summarize(n=n()) |> mutate(pct=100*n/sum(n))

# Averages by race (evaluations of Democratic party)
nes |> 
  group_by(Race3) |>
  summarize(avg=mean(ft_Dem, na.rm=TRUE))

# Averages by race (evaluations of Democratic party)
# Remove missing data 1: filter 
nes |> 
  filter(!is.na(Race3) & !is.na(ft_Dem)) |> 
  group_by(Race3) |>
  summarize(avg=mean(ft_Dem))

# Averages by race (evaluations of Democratic party)
# Remove missing data 2: drop_na 
nes |> 
  drop_na(Race3, ft_Dem) |> 
  group_by(Race3) |>
  summarize(avg=mean(ft_Dem))

# Revisiting data viz: PRE=ESTIMATION, bivariate plots
# geom_col, use haven's "as_factor"
nes |> drop_na(Race3, ft_Dem) |> group_by(Race3) |>
  summarize(avg=mean(ft_Dem)) |> 
  ggplot(aes(x=as_factor(Race3), y=avg)) + 
  geom_col(width=.3) + 
  labs(x=NULL, y="Thermometer: Democrats")


# Are those differences statistically significant? 
# "Dummying out" method for regression specification - manually
nes <- nes |> mutate(white = ifelse(Race3==1, 1, 0), 
                  black = ifelse(Race3==2, 1, 0),
                  hisp = ifelse(Race3==3, 1, 0)
                  )

nes |> drop_na(Race3) |> 
  group_by(Race3) |> summarize(n=n()) |> mutate(pct=100*n/sum(n))
nes |> drop_na(white) |> 
  group_by(white) |> summarize(n=n()) |> mutate(pct=100*n/sum(n))
nes |> drop_na(black) |> 
  group_by(black) |> summarize(n=n()) |> mutate(pct=100*n/sum(n))
nes |> drop_na(hisp) |> 
  group_by(hisp) |> summarize(n=n()) |> mutate(pct=100*n/sum(n))

# Change baselines
#Set white as baseline category
summary(lm(ft_Dem ~ black + hisp, data=nes))

# Set Hispanic as baseline category
summary(lm(ft_Dem ~ black + white, data=nes))

# Set Black as baseline category
summary(lm(ft_Dem ~ hisp + white, data=nes))

#Use built-in "as.factor" to dummy out race in the lm commmand
summary(lm(ft_Dem ~ as.factor(Race3), data=nes))

# Use built-in "relevel" command, set Hispanic as baseline
summary(lm(ft_Dem ~ relevel(as.factor(Race3), ref="3"), data=nes))

# Use built-in "relevel" command, set Black as baseline
summary(lm(ft_Dem ~ relevel(as.factor(Race3), ref="2"), data=nes))


# Post-estimation for multiple regression model

# Specify Race3 using factor; need this for post-estimation
a <- lm(ft_Dem ~ as_factor(Race3) + libcon7 + 
          Female + educ4, data=nes)
summary(a, digits=3)

# Use marginaleffects package, save predicted values, i.e., y-hats ("prediction")
race <- predictions(
  a,
  by="Race3",
  df = insight::get_df(a),
  numderiv = "richardson",
  newdata = datagrid(
    Race3=unique, grid_type="counterfactual"))

# Dots and spikes
race |> 
  ggplot(aes(y=estimate, x=as.factor(Race3), ymin = conf.low, ymax = conf.high)) + 
  geom_point(size=3) +
  geom_errorbar(width=0) +
  labs(x=NULL, y="Predicted Democratic Thermometer") +
  scale_x_discrete(breaks=c("1","2","3"),
                   labels=c("White", "Black", "Hispanic"))

# Bar graph with labels
race |> 
  ggplot(aes(y=estimate, x=as.factor(Race3), ymin = conf.low, ymax = conf.high,
             label = round(estimate, digits=2))) + 
  geom_bar(stat = "identity", alpha=.8, width = .5) +
  geom_errorbar(width=.08, size=.2) +
  labs(x=NULL, y="Predicted Democratic Thermometer") +
  scale_x_discrete(breaks=c("1","2","3"),
                   labels=c("White", "Black", "Hispanic")) +
  geom_text(vjust = 6, color="white", size=3.5)


## INTERACTIONS ##

# Supreme Court approval using feeling thermometer

# Don't forget to think about think about distribution of these DVs
ggplot(nes, aes(x=ft_SCOTUS)) +
  geom_histogram(color="white")

# We're interested in party and knowledge; see how they're coded, which is key for 
# interpretations of interactions
nes |> group_by(partyid7) |> summarize(n=n()) |> mutate(pct=100*n/sum(n))
nes |> group_by(polknow) |> summarize(n=n()) |> mutate(pct=100*n/sum(n))

# Model without interactions - unconditional effects of party and knowledge
summary(lm(ft_SCOTUS ~ partyid7 + polknow + Female + as.factor(Race3), data=nes))


# Model with interactions - conditional effects of party and knowledge
# First, use "full data" that includes missing data (lm takes it out automatically)
h <- lm(ft_SCOTUS ~ partyid7 + polknow + partyid7*polknow + as.factor(Female) + 
          as.factor(Race3), data=nes)
summary(h, digits=3)

# Alternative: If you include the multiplicative term, lm automatically
# includes the constituent terms. 
summary(lm(ft_SCOTUS ~ partyid7*polknow + as.factor(Female) + 
          as.factor(Race3), data=nes))

# I like to explicitly include the constituent terms. Also for post-estimation.

# Generate marginal effects of party id conditional on knowledge 
# We could do this manually -- write out equation

### Graph marginal effects (Brambor, Clark and Golder graph) 
# Use slopes command from marginaleffects package
mepid <- slopes(
  h, #model object
  variables = "partyid7", #variable for which we want marginal effect
  df = insight::get_df(h), #sets df for model to use t dist instead of z
  numderiv = "richardson", #SEs, delta method
  newdata = datagrid(polknow = 0:5)) #polknow the moderator, set range

# Use ggplot, dotted lines for 95% CIs; add horizontal zero line
ggplot(mepid, aes(x = polknow)) + 
  geom_line(aes(y = estimate)) +
  geom_line(aes(y = conf.high), linetype = 2) +
  geom_line(aes(y = conf.low), linetype = 2) +
  geom_hline(yintercept = 0) +
  labs(title="Marginal effect of Party ID", x="Political knowledge", 
       y="Marginal effect of Party ID")

# Use ribbon instead of dotted lines for 95% CI
ggplot(mepid, aes(x=polknow, y=estimate, ymin=conf.low, ymax=conf.high)) + 
  geom_line(color="black") +
  geom_ribbon(alpha=.3, fill="dodgerblue") +
  geom_hline(yintercept = 0, linetype="longdash", linewidth=.3) +
  labs(title="Marginal effect of Party ID", x="Political knowledge", 
       y="Marginal effect of Party ID")

# Use same concept, but use dots and rspikes
ggplot(mepid, aes(x=polknow, y=estimate, ymin=conf.low, ymax=conf.high)) + 
  geom_point(color="black", size=2) +
  geom_errorbar(width=0) +
  theme(plot.title = element_text(face="bold", size=12, hjust = 0.5)) +
  geom_hline(yintercept = 0, linetype="dashed") +
  theme_minimal() +
  labs(title="Marginal Effect of Party ID", x="Political knowledge", 
       y="Marginal effect of Party ID") +
  theme(plot.title = element_text(face="bold", size=12, hjust = 0.5))

# Flip to horizontal; typically used when you label the vertical axes with long labels
ggplot(mepid, aes(x=polknow, y=estimate, ymin=conf.low, ymax=conf.high)) + 
  geom_point(color="black", size=2) +
  geom_errorbar(width=0) +
  geom_hline(yintercept = 0, linetype="dashed") +
  theme_minimal() +
  coord_flip() +
  scale_x_continuous(breaks=c(0:5), 
                     labels=c('Very low knowledge','Low knowledge','Med-low knowledge',
                              'Med-high knowledge','High knowledge','Very high knowledge')) +
  labs(title="Marginal Effect of Party ID", x=NULL, 
       y="Marginal effect of Party ID") +
  theme(plot.title = element_text(face="bold", size=12, hjust = 0.5))


## Second way of graphing interactions: 
# Plot partial slopes for the effect of party on SC evals conditional on 
# low and high knowledge.

lknow <- predictions(
  h,
  by="partyid7",
  df = insight::get_df(h),
  numderiv = "richardson",
  newdata = datagrid(
    polknow = 0, partyid7=1:7, grid_type="counterfactual"))

hknow <- predictions(
  h,
  by="partyid7",
  numderiv = "richardson",
  df = insight::get_df(h),
  newdata = datagrid(
    polknow = 5, partyid7=1:7, grid_type="counterfactual"))

ggplot(data=lknow, aes(x=partyid7, y=estimate)) + 
  geom_line() +
  geom_line(data=hknow, aes(x=partyid7, y=estimate), color="dodgerblue") +
  geom_text(x=4, y=62, label="High pol. knowledge", color="dodgerblue") + 
  geom_text(x=5, y=53, label="Low pol. knowledge", color="black") +
  scale_x_continuous(breaks=c(1:7), labels=c('SD','WD','ID','I','IR','WR','SR')) +
  scale_y_continuous(limits = c(50, 65), breaks = seq(50, 65, by = 5)) + 
  theme_minimal() +
  labs(title="Conditional Effect of Party ID", x="Party ID",  
       y="Supreme Court Thermometer") +
  theme(plot.title = element_text(face="bold", size=12, hjust = 0.5))
