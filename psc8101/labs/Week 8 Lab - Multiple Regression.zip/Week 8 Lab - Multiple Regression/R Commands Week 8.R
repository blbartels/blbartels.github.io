library(haven)
library(tidyverse)
library(psych)
library(jtools)
library(skimr)

states <- read_dta("states.dta")

## SIMPLE REGRESSION (FROM LAST TIME)

# Estimate simple regression
model1 <- lm(womleg_2017 ~ conpct_m, data = states)
summ(model1, digits=3)

# t distribution: use pt(tvalue, df); cumulative distribution function
pt(-5, 48)
pt(-1.97, 48)

# inverse: use qt(pvalue, df)
qt(.025, 48)
qt(.025, 148)
qt(.025, 1000)
qt(.025, 2000)
qt(.025, 5000)
qt(.025, 1000000)


## MULTIPLE REGRESSION

# Add church att. and education; first review bivariate relationships: 

# Conservative % public
states |>
  ggplot(aes(x=conpct_m, y=womleg_2017)) + 
  geom_point() +
  geom_smooth(method="lm", se=FALSE) 

# Church attendance
states |>
  ggplot(aes(x=attend_pct, y=womleg_2017)) + 
  geom_point() +
  geom_smooth(method="lm", se=FALSE) 

# % College Grads
states |>
  ggplot(aes(x=ba_or_more_2015, y=womleg_2017)) + 
  geom_point() +
  geom_smooth(method="lm", se=FALSE) 

# Correlation matrix

states |> 
  select(womleg_2017, conpct_m, ba_or_more_2015, attend_pct) |> 
  cor() |> 
  knitr::kable(digits=3)

# Estimate multiple regression
a <- lm(womleg_2017 ~ conpct_m + attend_pct + ba_or_more_2015, data = states)
summ(a, digits=3)

# Save residuals and yhats; saves them in the states dataset (at the end)
states <- states |> mutate(wres=a$residuals, wyhat=a$fitted)
st_abb <- states |> select(womleg_2017, wres, wyhat)
# Later, we'll use these for diagnostics, e.g.,: 
states |>
  ggplot(aes(y=wres, x=wyhat)) + geom_point()
  
# Add smoothed line; what assumption is this testing? 
states |>
  ggplot(aes(y=wres, x=wyhat)) + geom_point() + geom_smooth(se=FALSE)

# alternative way to save resids and yhats: save as objects
uhat <- resid(a)
yhat <- fitted(a)

## Netting out interpretation; regress ba on other x's
ba <- lm(ba_or_more_2015 ~ conpct_m + attend_pct, data = states)

# Save residuals
states <- states |> mutate(ba_res=ba$residuals)

# Regress womleg on ba_res; note coefficient will be same, but not s.e.
c <- lm(womleg_2017 ~ ba_res, data = states)
summ(c, digits=3)

# Standardized coefficients
# First, manually standardize all your variables (both dependent and independent vars)
# Use the "scale" function
states <- states |> mutate(womleg_st = scale(womleg_2017), 
                   contpct_st = scale(conpct_m), 
                   attend_st = scale(attend_pct), 
                   ba_st = scale(ba_or_more_2015))
# Let's make sure it worked; what should we expect when we check mean and s.d. for transformed
# variables? 
skim(states, womleg_st, contpct_st, attend_st, ba_st)

# To get standardized coefficients, estimate a regression using the standardized
# variables. Just look at the coefficients, not the SEs. 
# Note that a model using standardized variables does not include a constant/intercept. It's 
# averaged out in the standardization. Thus, we can add a "0" to eliminate the constant.
lm(womleg_st ~ 0 + contpct_st + attend_st + ba_st, data=states)

# Another way to report standardized coefficients more quickly (and without first having
# to transform variables) is just running the regression with "scaled" variables in the call.
summ(
  lm(scale(womleg_2017) ~ 0 + scale(conpct_m) + scale(attend_pct) + 
     scale(ba_or_more_2015), data = states)
  , digits=3
)
