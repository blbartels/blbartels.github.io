# Simple regression

install.packages("jtools")

library(haven)
library(tidyverse)
library(psych)
library(jtools)
library(skimr)

states <- read_dta("states.dta")

# Reduced data set with only variables we're working with (optional)
statesub <- states %>% select(state, conpct_m, womleg_2017)

# Visualize - smoothed line
states %>%
  ggplot(aes(x=conpct_m, y=womleg_2017)) + 
  geom_point() +
  geom_smooth()

# Visualize - line of best fit
states %>%
  ggplot(aes(x=conpct_m, y=womleg_2017)) + 
  geom_point() +
  geom_smooth(method="lm")

# Remove error band
states %>%
  ggplot(aes(x=conpct_m, y=womleg_2017)) + 
  geom_point() +
  geom_smooth(method="lm", se=FALSE)

# Next, do correlation 
cor(states$womleg_2017, states$conpct_m)

# tidyverse command
summarize(states, cor(womleg_2017, conpct_m))

# Descriptive statistics
skim(states, womleg_2017, conpct_m)
describe(states$womleg_2017)
describe(states$conpct_m)

# Boxplot
ggplot(states, aes(y=womleg_2017)) + 
  geom_boxplot() +
  theme_minimal()

# Estimate simple regression
lm(womleg_2017 ~ conpct_m, data = states)

# Base R summary - save regression as object, then use "summmary"
model1 <- lm(womleg_2017 ~ conpct_m, data = states)
summary(model1)

# Or
summary(lm(womleg_2017 ~ conpct_m, data = states))

# Use jtools to report - "summ"
summ(model1)

# Or
summ(lm(womleg_2017 ~ conpct_m, data = states))