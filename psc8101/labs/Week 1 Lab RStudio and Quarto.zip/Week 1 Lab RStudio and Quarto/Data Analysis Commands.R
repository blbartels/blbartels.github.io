# This is an "R script" file (note the .R extension). 
# This contains data commands that you can run
# straight from this file. To execute a command, place the cursor 
# anywhere on the command line and hit "command-enter" for Mac 
# and "ctrl-enter" for PC. You can also click the "Run" button above.

# Install packages (once you install them, you never have to 
# install them again)
install.packages("tidyverse")
install.packages("haven")
install.packages("skimr")

# Load packages; you have to load packages every time you begin a 
# new RStudio session. You can also check "Packages" tab; if checked, 
# it's loaded.
library(tidyverse)
library(haven)
library(skimr)

# Load/open data

# Load Stata dataset via haven 
# Advantage of using .Rproj: place all datasets in project folder. 
# Easy to call them up. 
states <- read_dta("states.dta")
 
# Load .csv dataset via readr (loaded when you load tidyverse)
election <- read_csv("election.csv")

# Some datasets are available online that you can access by 
# installing and loading a package. See Ismay and Kim, Ch. 1

install.packages("nycflights13")
library(nycflights13)

# Note that the dataset "flights" isn't in our Environment.
# That's because it's accessible via this package we just installed.
# It's available to analyze within the R environment.

View(flights)

# We can add this data to our Environment if we want. 
flights <- flights

# Variables in the states data
ls(states)

# Basic descriptive statistics using skimr
skim(states, ba_or_more_2015, vep16_turnout)

# Scatterplot using ggplot (loaded via tidyverse package)
ggplot(data=states, aes(x=ba_or_more_2015, y=vep16_turnout)) +
  geom_point()


# Quarto:  Installing tools needed to run Quarto

# Install rmarkdown package; this also installs tinytex -- verify.
# We need tinytext to be able to render a Quarto document as a .pdf
install.packages("rmarkdown")

# Verify that tinytex is installed; see "Packages" tab

# Check if Latex is using tinytex
tinytex::is_tinytex()

# If "FALSE," we need to "set" tinytex as Latex this way: 
tinytex::install_tinytex()

# Now check again if Latex is using tinytex
tinytex::is_tinytex()

# Now let's test to make sure you can render a file as a .pdf.

# We'll open the test files in our files folder