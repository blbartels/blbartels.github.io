library(tidyverse)
library(haven)
library(skimr)
library(psych) # describe command below; skewness and kurtosis

nes <- read_dta("nes.dta")
world <- read_dta("world.dta")

# Central tendency: mean, median, mode

# Summary Statistics 
skim(nes, ft_Trump_post)

# Frequency distribution
nes |> group_by(educ4) |> summarize(n=n()) |>  mutate(pct=100*n/sum(n))
#freq(nes$educ4)

ggplot(nes, aes(x=ft_Trump_post)) +
  geom_histogram(binwidth=5, color="white")

ggplot(nes, aes(x=ft_HClinton_post)) +
  geom_histogram(binwidth=5, color="white")

# Skewness
ggplot(world, aes(x=gdp_10_thou)) +
  geom_density()

skim(world, gdp_10_thou)

# Use describe from psych package to get skewness and kurtosis
describe(world$gdp_10_thou)

# Variance and Standard Deviation
sd <- read_csv("sd.csv")
skim(sd, x)

## Crosstabs using "tabyl"
install.packages("janitor")
library(janitor)
library(knitr) #kable commmand; makes table look a bit better

# Create new "haven factor" factor vars to show value labels
nes$voted <- as_factor(nes$Voted_2016)
nes$ed <- as_factor(nes$educ4)

tabyl(nes, voted, ed, show_na=FALSE) |>
  adorn_totals(c("row", "col")) |>
  kable()

tabyl(nes, voted, ed, show_na=FALSE) |>
  adorn_totals(c("row", "col")) |>
  adorn_percentages("col") |>
  adorn_pct_formatting(digits=2) |>
  adorn_ns() |>
  kable()

# Simple probability distribution - education

# With missing data
tabyl(nes, ed, show_na=TRUE) |>
  adorn_totals("row") |> 
  kable() 

nes |> group_by(educ4) |> summarize(n=n()) |>  mutate(pct=100*n/sum(n))

# Removing missing data
tabyl(nes, ed, show_na=FALSE) |>
  adorn_totals("row") |> 
  kable() 

nes |> drop_na(educ4) |> group_by(educ4) |> summarize(n=n()) |>  
  mutate(pct=100*n/sum(n))

## Probability exercise - contingency table/crosstab

# Convert to "haven factor" (haven package); show value labels in tables
nes$ideo <- as_factor(nes$libcon3) 
nes$pid <- as_factor(nes$partyid3)

tabyl(nes, ideo, pid, show_na=FALSE) |>
  adorn_totals(c("row", "col")) |> 
  kable()
  
## Report column probabilities
tabyl(nes, ideo, pid, show_na=FALSE) |>
  adorn_totals(c("row", "col")) |>
  adorn_percentages("col") |> 
  adorn_ns() |> 
  kable()

## Report row probabilities
tabyl(nes, ideo, pid, show_na=FALSE) |>
  adorn_totals(c("row", "col")) |>
  adorn_percentages("row") |>
  adorn_ns() |>
  kable()

