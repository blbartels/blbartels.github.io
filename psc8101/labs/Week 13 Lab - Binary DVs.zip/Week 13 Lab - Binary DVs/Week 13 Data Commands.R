library(haven)
library(tidyverse)
library(jtools)
library(marginaleffects)
library(skimr)
library(estimatr)

nes <- read_dta("nes.dta")

# Summarize key variables in vote choice model

# Dependent variable: 1=Clinton, 0=Trump
nes |> drop_na(Clinton_vote) |> group_by(Clinton_vote) |> summarize(n=n()) |> mutate(pct=100*n/sum(n))

# Independent variables
nes |> group_by(better_worse_past_econ) |> summarize(n=n()) |> mutate(pct=100*n/sum(n))
nes |> group_by(partyid7) |> summarize(n=n()) |> mutate(pct=100*n/sum(n))
nes |> group_by(Relig_attend) |> summarize(n=n()) |> mutate(pct=100*n/sum(n))
nes |> group_by(Race3) |> summarize(n=n()) |> mutate(pct=100*n/sum(n))

# Summarize all variables
nes |> skim(Clinton_vote, better_worse_past_econ, partyid7, Relig_attend)

# Logit model using "glm" 
vote_l <- glm(Clinton_vote ~ better_worse_past_econ + 
            partyid7 + Relig_attend + as.factor(Race3), 
            family=binomial(link=logit), data=nes)
summary(vote_l, digits=4)

# Goodness of fit: Proportional reduction in error (PRE)
# First, save "fitted values" (predicted prob(Clinton) for each observation); 
# generate whether observation is "correctly predicted" or not (using .5 threshold).
# Using the "fitted" command requires removing all missing data. 
# Note I create new data object, "nes_fit"
nes_fit <- nes |> 
  drop_na(Clinton_vote, better_worse_past_econ, partyid7, Relig_attend, Race3) |> 
  mutate(prob=fitted(vote_l), 
         correct=ifelse(prob>.5 & Clinton_vote==1, 1, 0), 
         correct=ifelse(prob<.5 & Clinton_vote==0, 1, correct))

# Second, generate three core measures -- PMC, PCP, and PRE -- from the "nes_fit" object 
# NOTE: if "1" is the modal category of DV (which it is in this case), use code below for "PMC": PMC=mean(Clinton_vote)
# If "0" is the modal category of DV, use: PMC=1-mean(Clinton_vote)
nes_fit |> summarize(PMC=mean(Clinton_vote), PCP=mean(correct)) |> 
  mutate(PRE = (PCP-PMC) / (1-PMC) )

# Using "predictions" from "marginaleffects" package to generate predicted probs.

## ECONOMIC PERCEPTIONS

## AVG CASE APPROACH 
econ_ac_l <- predictions(
  vote_l,
  by = "better_worse_past_econ",
  numderiv = "richardson",
  newdata = datagrid(better_worse_past_econ = 1:5, 
                     grid_type = "counterfactual"))
head(econ_ac_l)
## OBSERVED VALUE APPROACH 
econ_ov_l <- predictions(
  vote_l,
  type = "response",
  by = "better_worse_past_econ",
  newdata = datagrid(better_worse_past_econ = 1:5, 
                     grid_type = "counterfactual"))
head(econ_ov_l)
## RACE

## AVG CASE
race_ac_l <- predictions(
  vote_l, 
  by = "Race3",
  numderiv = "richardson",
  newdata = datagrid(Race3 = 1:3, 
                     grid_type = "counterfactual"))
head(race_ac_l)
## OBSERVED VALUE
race_ov_l <- predictions(
  vote_l, 
  type = "response",
  by = "Race3",
  numderiv = "richardson",
  newdata = datagrid(Race3 = 1:3, 
                     grid_type = "counterfactual"))
head(race_ov_l)

# Compare AC to OV: Econ Perceptions

ggplot(econ_ac_l, aes(x=better_worse_past_econ, y=estimate)) +
  geom_line(color="black") +
  geom_line(data=econ_ov_l, aes(x=better_worse_past_econ, y=estimate), color="dodgerblue") +
  labs(x="Economic perceptions", y="Predicted Prob(Clinton Vote)") +
  geom_text(x=2, y=.86, label="Avg. case", color="black") +
  geom_text(x=1.5, y=.6, label="Obs. value", color="dodgerblue") +
  scale_x_continuous(breaks=c(1:5), labels=c("Better", "2", "3", "4", "Worse")) +
  scale_y_continuous(limits = c(.1, 1), breaks = seq(.1, 1, by = .10))
  
# Compare AC to OV: Race

ggplot(race_ac_l, aes(x=as.numeric(Race3), y=estimate)) +
  geom_line(color="black") + 
  geom_line(data=race_ov_l, aes(x=as.numeric(Race3), y=estimate), color="dodgerblue") +
  labs(x="", y="Predicted Prob(Clinton Vote)") +
  geom_text(x=2, y=.93, label="Avg. case", color="black") +
  geom_text(x=1.5, y=.5, label="Obs. value", color="dodgerblue") +
  scale_x_continuous(breaks=c(1:3), labels=c("White", "Black", "Hispanic")) +
  scale_y_continuous(limits = c(.1, 1), breaks = seq(.1, 1, by = .10))


# Probit
vote_p <- glm(Clinton_vote ~ better_worse_past_econ + 
                partyid7 + Relig_attend + as.factor(Race3), 
              family=binomial(link=probit), data=nes)
summary(vote_p, digits=4)

# ECON PERCEPTIONS 

# AVERAGE CASE APPROACH
econ_ac_p <- predictions(
  vote_p,
  by = "better_worse_past_econ",
  numderiv = "richardson",
  newdata = datagrid(better_worse_past_econ = 1:5, 
                     grid_type = "counterfactual"))
head(econ_ac_p)
## OBSERVED VALUE APPROACH 
econ_ov_p <- predictions(
  vote_p,
  type = "response",
  by = "better_worse_past_econ",
  newdata = datagrid(better_worse_past_econ = 1:5, 
                     grid_type = "counterfactual"))
head(econ_ov_p)
## RACE

## AVG CASE
race_ac_p <- predictions(
  vote_p, 
  by = "Race3",
  numderiv = "richardson",
  newdata = datagrid(Race3 = 1:3, 
                     grid_type = "counterfactual"))
head(race_ac_p)
## OBSERVED VALUE
race_ov_p <- predictions(
  vote_p, 
  type = "response",
  by = "Race3",
  numderiv = "richardson",
  newdata = datagrid(Race3 = 1:3, 
                     grid_type = "counterfactual"))
head(race_ov_p)
# Compare logit v. probit probs (obs. value): Econ
ggplot(econ_ov_l, aes(x=better_worse_past_econ, y=estimate)) +
  geom_line(color="black") +
  geom_line(data=econ_ov_p, aes(x=better_worse_past_econ, y=estimate), color="dodgerblue") +
  labs(x="Economic perceptions", y="Predicted Prob(Clinton Vote)") +
  geom_text(x=2, y=.7, label="Logit", color="black") +
  geom_text(x=1.5, y=.6, label="Probit", color="dodgerblue") +
  scale_x_continuous(breaks=c(1:5), labels=c("Better", "2", "3", "4", "Worse")) +
  scale_y_continuous(limits = c(.1, 1), breaks = seq(.1, 1, by = .10))

# Compare logit v. probit probs (obs. value): Race
ggplot(race_ov_l, aes(x=as.numeric(Race3), y=estimate)) +
  geom_line(color="black") + 
  geom_line(data=race_ov_p, aes(x=as.numeric(Race3), y=estimate), color="dodgerblue") +
  labs(x="", y="Predicted Prob(Clinton Vote)") +
  geom_text(x=2, y=.75, label="Logit", color="black") +
  geom_text(x=1.5, y=.5, label="Probit", color="dodgerblue") +
  scale_x_continuous(breaks=c(1:3), labels=c("White", "Black", "Hispanic")) +
  scale_y_continuous(limits = c(.1, 1), breaks = seq(.1, 1, by = .10))

# LPM with robust standard errors; use lm_robust from estimatr package
vote_lpm <- lm_robust(Clinton_vote ~ better_worse_past_econ + 
              partyid7 + Relig_attend + as.factor(Race3), data=nes, 
              se_type="stata")
summary(vote_lpm)

# Pred. probs: Econ
econ_lpm <- predictions(
  vote_lpm, 
  by = "better_worse_past_econ",
  df = insight::get_df(vote_lpm),
  numderiv = "richardson",
  newdata = datagrid(better_worse_past_econ = 1:5, 
                     grid_type="counterfactual"))
head(econ_lpm)
# Compare logit (obs. value) and LPM
ggplot(econ_ov_l, aes(x=better_worse_past_econ, y=estimate)) +
  geom_line(color="black") +
  geom_line(data=econ_lpm, aes(x=better_worse_past_econ, y=estimate), color="dodgerblue") +
  labs(x="Economic perceptions", y="Predicted Prob(Clinton Vote)") +
  geom_text(x=2, y=.7, label="Logit (Obs. Value)", color="black") +
  geom_text(x=1.5, y=.6, label="LPM", color="dodgerblue") +
  scale_x_continuous(breaks=c(1:5), labels=c("Better", "2", "3", "4", "Worse")) +
  scale_y_continuous(limits = c(.1, 1), breaks = seq(.1, 1, by = .10))

# Compare probit (OV) and LPM
ggplot(econ_ov_p, aes(x=better_worse_past_econ, y=estimate)) +
  geom_line(color="black") +
  geom_line(data=econ_lpm, aes(x=better_worse_past_econ, y=estimate), color="dodgerblue") +
  labs(x="Economic perceptions", y="Predicted Prob(Clinton Vote)") +
  geom_text(x=2, y=.7, label="Probit (Obs. Value)", color="black") +
  geom_text(x=1.5, y=.6, label="LPM", color="dodgerblue") +
  scale_x_continuous(breaks=c(1:5), labels=c("Better", "2", "3", "4", "Worse")) +
  scale_y_continuous(limits = c(.1, 1), breaks = seq(.1, 1, by = .10))