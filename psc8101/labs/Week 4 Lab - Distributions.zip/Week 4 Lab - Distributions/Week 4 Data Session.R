library(tidyverse)
library(psych)
library(haven)
library(skimr)

states <- read_dta("states.dta")

#Kernel density plot of women's representation
ggplot(states, aes(x = womleg_2017)) +
  geom_density()

# Get mean and sd
skim(states, womleg_2017)

describe(states$womleg_2017)

# Use dnorm to get density (PDF) values associated with values of womleg_2017
# Note density plot based on Kernel estimation reported as density. 
# Let's you compare how distribution deviates from normal density.
# dnorm gives you density values if the variable were actually normally distributed;
# it's using the actual equation for the normal PDF.
dnorm(20, mean=25.03, sd=7.64)
dnorm(25, mean=25.03, sd=7.64)
dnorm(30, mean=25.03, sd=7.64)
dnorm(15, mean=25.03, sd=7.64)
dnorm(40, mean=25.03, sd=7.64)

# Overlay "normal" with "actual" to visualize how much it deviates from normal.
states$dens <- dnorm(states$womleg_2017, mean=25.03, sd=7.64)

ggplot(states) + 
  geom_line(aes(x=womleg_2017, y=dens), color="red") +
  geom_density(aes(x=womleg_2017))


## Use pnorm to calculate quantities associated with the CDF.
## Example of Bobby's LSAT score
pnorm(950, mean=1100, sd=200)
pnorm(950, 1100, 200)
# What's the fraction of test-takers who scored higher than Bobby? 
1- pnorm(950, mean=1100, sd=200)

# Z-score transformation
states$zwomleg_2017 <- (states$womleg_2017 - 25.03) / 7.64

#Check mean and sd for z-score version of womleg_2017
skim(states, zwomleg_2017)

#Density plot
ggplot(states, aes(x = zwomleg_2017)) +
  geom_density()

## Use Z-scores to do examples about Bobby's LSAT 
pnorm(-.75)
1-pnorm(-.75)

## Use "qnorm" to find Z score associated with percentile (Suzie example)
qnorm(.45)

## Check your binomial calculations using the dbinom(k, n, p) function
dbinom(2, 4, .45)

## Find Z for 95% confidence interval
qnorm(.025)
pnorm(-1.96)
1-pnorm(1.96)
qnorm(.05)
