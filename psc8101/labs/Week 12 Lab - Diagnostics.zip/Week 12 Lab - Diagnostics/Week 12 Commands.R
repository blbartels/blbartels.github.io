library(haven)
library(tidyverse)
library(margins)
library(jtools)
library(ggrepel)
library(lmtest)
library(car)
library(estimatr)

nes <- read_dta("nes.dta")
states <- read_dta("states.dta")

# Multicollinearity
a <- lm(ft_Trump_pre ~ partyid7 + libcon7 + better_worse_past_econ + Female + educ4 + 
          as.factor(Race3) + income5 + Age, data=nes)
summary(a)

# Correlation matrix
nes |> 
  drop_na(partyid7, libcon7, better_worse_past_econ) |> 
  select(partyid7, libcon7, better_worse_past_econ) |> 
  cor()

# Pairwise correlations
cor(nes$partyid7, nes$libcon7, use="complete.obs")
cor(nes$partyid7, nes$better_worse_past_econ, use="complete.obs")
cor(nes$libcon7, nes$better_worse_past_econ, use="complete.obs")

## Variance inflation factor from car package
vif(a)

# Heteroscedasticity
b <- lm(vep16_turnout ~ south + ba_or_more_2015 + hispanicpct_2016 + blackpct_2016, 
        data=states)
summary(b, digits=3)

## Save residuals and y-hats to states data
states <- states |> mutate(res=residuals(b))
states <- states |> mutate(yhat=fitted(b))

#Graph residuals against y-hats
states |> 
  ggplot(aes(x=yhat, y=res)) + 
  geom_point() +
  geom_hline(yintercept = 0)

## Graph residuals against x variables, look for patterns
states |> 
  ggplot(aes(x=ba_or_more_2015, y=res)) + 
  geom_point() + 
  geom_hline(yintercept = 0)

states |> 
  ggplot(aes(x=hispanicpct_2016, y=res)) + 
  geom_point() + 
  geom_hline(yintercept = 0)

states |> 
  ggplot(aes(x=blackpct_2016, y=res)) + 
  geom_point() + 
  geom_hline(yintercept = 0)

states |> 
  ggplot(aes(x=south, y=res)) + 
  geom_point() + 
  geom_hline(yintercept = 0)

# Breusch-Pagan test for heteroskedasticity (bptest in "lmtest" package)
bptest(b, studentize = FALSE)

# Covariate specific tests
bptest(b, ~ba_or_more_2015, data=states, studentize = FALSE)
bptest(b, ~hispanicpct_2016, data=states, studentize = FALSE)
bptest(b, ~blackpct_2016, data=states, studentize = FALSE)
bptest(b, ~south, data=states, studentize = FALSE)

## Robust standard errors
## lm_robust from the "estimatr" package; note that "stata" = "HC1"
# Note that lm_robust is compatible with texreg for reporting results in Quarto
c <- lm_robust(vep16_turnout ~ south + ba_or_more_2015 + hispanicpct_2016 + 
                 blackpct_2016, se_type="stata", data=states)
summary(c)

# Unusual observations (outliers and influence)

## Studentized residuals for outliers
## Save st. res. to states data
states <- states |> mutate(sres=rstudent(b))

# Generate observation counter (1 to 50) 
states <- states |> mutate(obs=1:nrow(states))

# Graph
states |>
  ggplot(aes(x=obs, y=sres, label=StateID)) + 
  geom_point() + 
  geom_text_repel() +
  geom_hline(yintercept=2, linetype="dashed") + 
  geom_hline(yintercept=-2, linetype="dashed")

# Influence statistics using DFBETAS
states <- states |> mutate(dfb=dfbetas(b))

# Graph
states |>
  ggplot(aes(x=obs, y=dfb[,"ba_or_more_2015"], label=StateID)) + 
  geom_point() + 
  geom_text_repel() + 
  geom_hline(yintercept=2/sqrt(50)) + 
  geom_hline(yintercept=-2/sqrt(50))

states |>
  ggplot(aes(x=obs, y=dfb[,"south"], label=StateID)) + 
  geom_point() + 
  geom_text_repel() + 
  geom_hline(yintercept=2/sqrt(50)) + 
  geom_hline(yintercept=-2/sqrt(50))

states |>
  ggplot(aes(x=obs, y=dfb[,"hispanicpct_2016"], label=StateID)) + 
  geom_point() + 
  geom_text_repel() + 
  geom_hline(yintercept=2/sqrt(50)) + 
  geom_hline(yintercept=-2/sqrt(50))

states |>
  ggplot(aes(x=obs, y=dfb[,"blackpct_2016"], label=StateID)) + 
  geom_point() + 
  geom_text_repel() + 
  geom_hline(yintercept=2/sqrt(50)) + 
  geom_hline(yintercept=-2/sqrt(50))

# Normality of errors
#Density plot of residuals
states |> 
  ggplot(aes(x=res)) + 
  geom_density()

states |> 
  ggplot(aes(x=sres)) + 
  geom_density()

# Jarque Bera test for normality; install tsoutliers package
library(tsoutliers)

JarqueBera.test(residuals(b))
