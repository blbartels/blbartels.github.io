library(haven)
library(tidyverse)
library(jtools)

# Two new packages we haven't used before (install those):
install.packages("car")
install.packages("marginaleffects")
library(car)
library(marginaleffects)

# Nonlinear functional forms

occ <- read_dta("occ.dta")

# Bivariate scatterplots
occ |>
  ggplot(aes(x=percwomn, y=prestige)) +
  geom_point() +
  geom_smooth(se=FALSE) +
  geom_smooth(method ="lm", se=FALSE, color="black", linewidth=.5) 

occ |>
  ggplot(aes(x=income, y=prestige)) +
  geom_point() +
  geom_smooth(se=FALSE) +
  geom_smooth(method ="lm", se=FALSE, color="black", linewidth=.5)

occ |>
  ggplot(aes(x=educat, y=prestige)) +
  geom_point() +
  geom_smooth(se=FALSE) +
  geom_smooth(method ="lm", se=FALSE, color="black", linewidth=.5)

# Estimate regression model
a <- lm(prestige ~ percwomn + income + educat, data = occ)  
summ(a, digits=4)

# Store coefficients in 1 x k vector
cf <- coef(a)

# Save residuals
occ <- occ |> mutate(res=a$residuals)

# Generate partial residuals
occ <- occ |> mutate(pr_perc = res + percwomn*cf[2],
                      pr_inc = res + income*cf[3],
                      pr_ed = res + educat*cf[4]
                      )

# Plot partial residuals: percwomn
occ |>
  ggplot(aes(x=percwomn, y=pr_perc)) +
  geom_point() +
  geom_smooth(se=FALSE) +
  geom_smooth(method ="lm", se=FALSE, color="black", linewidth=.5)

# Plot partial residuals: income
occ |>
  ggplot(aes(x=income, y=pr_inc)) +
  geom_point() +
  geom_smooth(se=FALSE) +
  geom_smooth(method ="lm", se=FALSE, color="black", linewidth=.5)

# Plot partial residuals: educat
occ |>
  ggplot(aes(x=educat, y=pr_ed)) +
  geom_point() +
  geom_smooth(se=FALSE) +
  geom_smooth(method ="lm", se=FALSE, color="black", linewidth=.5)

# Use crPlots from car package
crPlots(a)

# Estimate new regression model with nonlinear functional forms:

b <- lm(prestige ~ percwomn + I(percwomn^2) + log(income) + educat, 
        data = occ)
summ(b, digits=5)

# Use the "marginaleffects" package to produce post-estimation plots
# www.marginaleffects.com

# Plot predicted values of Y against independent variable (to show nonlinear 
# functional form). These are **post-estimation plots**.

# Two ways to do this

# 1.  Use "predictions" command (from marginaleffects)
pw1 <- predictions(
  b, 
  by="percwomn", 
  df = insight::get_df(b), # retrieves degrees of freedom from model
  numderiv = "richardson", # uses delta method for SEs
  newdata = datagrid(
    percwomn=unique, grid_type="counterfactual")) 
# unique = unique values of percwomn

# 2.  Use "avg_predictions" command (from marginaleffects)
pw2 <- avg_predictions(
  b, 
  variables = list(percwomn = unique), by = "percwomn", 
  df = insight::get_df(b), 
  numderiv = "richardson"
) 

# Graph with no error bands - margins
pw1 |>
  ggplot(aes(x=percwomn, y=estimate)) + geom_line()

# Graph with error bands
pw1 |>
  ggplot(aes(x=percwomn, y=estimate, ymin=conf.low, ymax=conf.high)) + 
  geom_line(color="black") +
  geom_ribbon(alpha=.3, fill="dodgerblue")

# Do the same for income - log transformation
inc <- predictions(
  b, 
  by="income", 
  df = insight::get_df(b), 
  numderiv = "richardson", 
  newdata = datagrid(
    income=unique, grid_type="counterfactual")) 

inc |>
  ggplot(aes(x=income, y=estimate, ymin=conf.low, ymax=conf.high)) + 
  geom_line(color="black") +
  geom_ribbon(alpha=.3, fill="dodgerblue") +
  theme_minimal(base_size = 10)

# Aside: Change "base_size" - overall font size for all parts
inc |>
  ggplot(aes(x=income, y=estimate, ymin=conf.low, ymax=conf.high)) + 
  geom_line(color="black") +
  geom_ribbon(alpha=.3, fill="dodgerblue") +
  theme_bw(base_size = 14)

# Generating marginal effects

# Get coeffs from model
cf2 <- coef(b)

# Generate marginal effects
occ <- occ |> mutate(b_pw=cf2[2] + 2*cf2[3]*percwomn)

# List marginal effects
me_pw <- occ |>
  group_by(percwomn) |>
  summarize(me=mean(b_pw, na.rm=TRUE))

# Use marginaleffects package
me_pw2 <- slopes(
  b, 
  variables = "percwomn", 
  df = insight::get_df(b), 
  numderiv = "richardson", 
  newdata = datagrid(
    percwomn=unique)
)

# Marginal effects for income
me_inc <- slopes(
  b, 
  variables = "income", 
  df = insight::get_df(b), 
  numderiv = "richardson", 
  newdata = datagrid(
    income=unique)
)
