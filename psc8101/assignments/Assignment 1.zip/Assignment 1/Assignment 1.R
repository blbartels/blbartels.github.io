# Load all packages here


# Load all data files here


# Put all graphing commands here. Once you know they all work, then
# copy and paste commands over to .qmd file (in R code chunks).


## Number 1

# 1A

# 1B

# 1C

# 1D


## Number 2

# 2A

# 2B


## Number 3

# 3B

# 3C

# 3D


## Number 4

# 4A

# 4B

# 4C